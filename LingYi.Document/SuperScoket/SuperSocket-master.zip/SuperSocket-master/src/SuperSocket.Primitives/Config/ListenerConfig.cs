namespace SuperSocket.Config
{
    public class ListenerConfig
    {
        public string Ip { get; set; }

        public int Port  { get; set; }

        public int BackLog { get; set; }
    }
}