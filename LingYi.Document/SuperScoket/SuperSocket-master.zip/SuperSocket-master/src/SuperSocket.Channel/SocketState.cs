using System;
using System.Threading.Tasks;

namespace SuperSocket.Channel
{
    public enum SocketState
    {
        Connected,
        Closing,
        Closed
    }
}
